# ☁️ دليل الرفع والتشغيل والفحص والأمان — سحابي بالكامل

> تشغيل سحابي خالص. المشترك لا يحمّل ولا يشغّل شيئًا. كل شيء يُدار مركزيًا من لوحة المالك.
> repo `abdulellahsh11-stack/bot` · الخدمة `bot-afcw.onrender.com`.

---

## 🗺️ بنية التشغيل السحابي

```
Render
├── (1) خدمة ويب  server.py + auth.py     ← اللوحة + المصادقة + قاعدة الحسابات (SQLite على قرص دائم)
└── (2) عامل خلفي supervisor.py            ← يعمل 24/7، يدير BotAgent لكل مشترك نشط
                                             يقرأ الإعدادات من (1) عبر الـ API فقط
                          │ ADB عبر الإنترنت
                          ▼
GeeLark — هواتف سحابية (مزرعة لكل مشترك)     ← البوت يعمل هنا، لا على أي جهاز محلي
```

> ⚠️ قاعدة Render: القرص الدائم يخصّ خدمة واحدة فقط ولا يُشارك بين الخدمات. لذلك قاعدة الحسابات تبقى ملك **خدمة الويب** وحدها، و**المُشرف** يصل إليها عبر الـ API لا عبر الملف. عند الحاجة لمشاركة مباشرة أو توسّع أفقي، انتقل إلى **Render Postgres**.

---

## 1) الرفع (Deployment)

### أ. خدمة الويب (اللوحة + المصادقة)
1. ضع `auth.py` في `server/` بجوار `server.py`.
2. في `server_requirements.txt` أضف: `pydantic[email]` و`PyJWT`.
3. اربط في `server.py`:
   ```python
   from fastapi.middleware.cors import CORSMiddleware
   from auth import router as auth_router, init_db
   init_db()
   app.include_router(auth_router)
   app.add_middleware(CORSMiddleware,
       allow_origins=["https://bot-afcw.onrender.com"],
       allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
   ```
4. **اجعلها مدفوعة Starter ($7/شهر)** ثم **Add Disk** بمسار `/var/data` (يلزم قرص لبقاء الحسابات؛ Free لا يدعم قرصًا).
5. متغيّرات البيئة (Environment):
   | المفتاح | القيمة |
   |--------|--------|
   | `JWT_SECRET` | مفتاح عشوائي طويل |
   | `SUPER_EMAIL` / `SUPER_PW` | بيانات المالك |
   | `DEBUG` | `0` |
   | `DB_PATH` | `/var/data/whiteout.db` |

   توليد المفتاح (من Render Shell أو أي بيئة): `python -c "import secrets;print(secrets.token_urlsafe(48))"`

### ب. العامل الخلفي (المُشرف)
- Render → New → **Background Worker** من نفس المستودع.
- Start Command: `python supervisor.py`
- متغيّراته: رابط اللوحة `PANEL_URL=https://bot-afcw.onrender.com` + توكن خدمة (`SERVICE_TOKEN`) يصادق به على الـ API. **لا تعطه `DB_PATH`** — لا يلمس القاعدة مباشرة.
- بيانات GeeLark (مفتاح API + قائمة الأجهزة) تُوضع هنا أيضًا.

### ج. GeeLark
- باقة Base لفتح ADB، ثم جهاز سحابي لكل مزرعة، والاتصال عبر ADB على الإنترنت `IP:PORT` (يدعمه `adb.py`).

### د. النشر
```
git add server/ && git commit -m "cloud auth" && git push
```
Render ينشر الخدمتين تلقائيًا. راقب حتى: `Application startup complete`.

---

## 2) التشغيل (كله سحابي)

- الخدمتان تعملان **24/7 على Render**، والبوت على **GeeLark** — بلا محاكي محلي وبلا `START_*.bat`.
- **المالك**: يوافق على الاشتراكات، يضبط الفترات والمهام من اللوحة، ويتابع التقارير.
- **المشترك**: يسجّل، يضيف مزارعه، يختار المهام — لا يشغّل شيئًا.
- أول إقلاع لخدمة الويب يُنشئ حساب المالك والأدوار والصلاحيات تلقائيًا (Seed).
- **الفترة/فترة الزيارة** تُدار من لوحة المالك (إعداد عام).

---

## 3) الفحص (سحابي)

### أ. اختبارات آلية عبر GitHub Actions (تعمل في السحابة عند كل push)
أنشئ `.github/workflows/tests.yml`:
```yaml
name: tests
on: [push]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with: { python-version: "3.12" }
      - run: pip install fastapi "pydantic[email]" PyJWT pytest httpx
      - run: pytest -q       # المتوقع: 8 passed
```
> بديل: شغّل `pytest -q` من **Render Shell** (SSH) داخل الخدمة نفسها.

### ب. فحص حيّ بعد النشر (من أي مكان)
```bash
# 1) واجهة التوثيق:  https://bot-afcw.onrender.com/docs
# 2) دخول المالك → توكن
curl -s -X POST https://bot-afcw.onrender.com/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"بريد_المالك","password":"كلمة_المرور"}'
# 3) الهوية
curl -s https://bot-afcw.onrender.com/auth/me -H "Authorization: Bearer <ACCESS>"
# 4) الحماية: بلا توكن يجب 401
curl -s -o /dev/null -w "%{http_code}\n" https://bot-afcw.onrender.com/users
```

### ج. قائمة سلوكية
- [ ] `/docs` تفتح. دخول المالك يُرجع `access` و`refresh`.
- [ ] `/auth/me` تُظهر `super_admin` وكل الصلاحيات.
- [ ] `/users` بلا توكن = 401 · بتوكن مستخدم عادي = 403.
- [ ] مستخدم غير مُفعّل البريد = 403 · 5 محاولات خاطئة = 429.
- [ ] المُشرف يقرأ إعدادات المشتركين عبر الـ API بنجاح.

---

## 4) الأمان (قائمة ما قبل الإطلاق)

**أسرار وبنية**
- [ ] `JWT_SECRET` قوي فريد · `DEBUG=0` · بيانات المالك مُغيَّرة بعد أول دخول.
- [ ] لا أسرار في الكود — فقط Environment. المستودع **عام**؛ يُفضّل جعله Private واحذف أي سرّ من تاريخه.
- [ ] قاعدة الحسابات على قرص دائم (خدمة الويب فقط). للتوسّع/المشاركة لاحقًا: **Render Postgres**.
- [ ] `.env` و`*.db` في `.gitignore`.

**قناة GeeLark/ADB**
- [ ] لا تعرّض منفذ ADB علنًا؛ قيّده بـ IP المُشرف أو نفق آمن. عامل GeeLark كسرّ في Environment.

**محمي أصلًا في `auth.py`**
- تجزئة PBKDF2 (لا نص صريح) · قفل 5 محاولات/15 دقيقة · رسالة دخول عامة · SQL مُعامَل · منع تصعيد الصلاحيات · سجل تدقيق · حذف ناعم + إبطال الجلسات.

**ترقيات موصى بها**
- [ ] تحويل التوكنات إلى **HttpOnly + Secure + SameSite Cookies** من الخادم.
- [ ] حصر CORS على النطاق (مطبّق) · HTTPS يفرضه Render.
- [ ] تنبيه: خدمة بقرص لا تدعم النشر بلا انقطاع (تتوقف ثوانٍ عند كل نشر) — طبيعي.

---

### مرجع سريع
| البند | القيمة |
|------|--------|
| Access / Refresh | 15 دقيقة / 7 أيام |
| قفل الدخول | 5 محاولات / 15 دقيقة |
| تجربة Test | 36 ساعة، مرة واحدة، تُمدّد من المالك |
| الخدمات | ويب (لوحة+مصادقة) + عامل خلفي (مُشرف) + GeeLark |
| قاعدة الحسابات | SQLite على قرص خدمة الويب (أو Postgres لاحقًا) |
| اختبار | GitHub Actions → `pytest` → 8 passed |
